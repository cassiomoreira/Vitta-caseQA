import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class SaraivaCadastro {
	//System.setProperty("webdriver.chrome.driver", "/home/cassio/eclipse-workspace/Cadastro_Saraiva/chromedriver");
	private WebDriver driver;

	@Given("^que eu acesso o site de cadastro da \"https://www.saraiva.com.br/login?ReturnUrl=%2f_secure%2faccount")
	public void que_eu_acesso_o_site_de_cadastro_da(String arg1) throws Throwable {
		driver.get(arg1);
	}

	@Given("^eu escolha a opcao de \"vtexIdUI-saraiva-oauth")
	public void eu_escolha_a_opcao_de(String arg1) throws Throwable {
		driver.findElement(By.id(arg1)).click();;
	}

	@Given("^eu escolha a opcao nao \"([^\"]*)\"$")
	public void eu_escolha_a_opcao_nao(String arg1) throws Throwable {
		driver.findElement(By.xpath("//a[@class='btn btn--block btn-large m-t-15 cadastrar-usuario']")).click();

	}

	@Given("^eu preencha os dados pessoas de pessoa fisica$")
	public void eu_preencha_os_dados_pessoas_de_pessoa_fisica() throws Throwable {
		driver.findElement(By.id("InputNome1")).sendKeys("Fulano");
		driver.findElement(By.id("InputNome2")).sendKeys("de tal");
		driver.findElement(By.id("InputEmail1")).sendKeys("teste@teste.com");
		driver.findElement(By.id("InputSenha1")).sendKeys("123456789");
		driver.findElement(By.id("InputConfirmeSenha1")).sendKeys("123456789");
		driver.findElement(By.id("InputCpf1")).sendKeys("123456789");
		driver.findElement(By.id("RadioMasculino1")).click();
		driver.findElement(By.id("InputDataNascimento1")).sendKeys("123456789");
		driver.findElement(By.id("InputCelular1")).sendKeys("123456789");
		driver.findElement(By.id("InputCep1")).sendKeys("123456789");
		driver.findElement(By.id("InputNumero1")).sendKeys("123456789");
		driver.findElement(By.id("InputTelefone1")).sendKeys("123456789");

	}

	@When("^eu confirmar \"FinalizarCadastro1")
	public void eu_confirmar(String arg1) throws Throwable {
		driver.findElement(By.id(arg1)).click();

	}

	@Then("^meu cadastro sera finalizado com sucesso$")
	public void meu_cadastro_sera_finalizado_com_sucesso() throws Throwable {
		System.out.println("Cadastro realizado com sucesso");

	}

	@Given("^vou ver uma \"([^\"]*)\"$")
	public void vou_ver_uma(String arg1) throws Throwable {
		WebElement texto = driver.findElement(By.xpath("//*[@id=\"modalMensagem\"]/div/div[2]/p[1]"));
		Assert.assertEquals("Usuário Cadastrado com sucesso", texto.getText());
	}

}
